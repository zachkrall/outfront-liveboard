/*

    Subway Traffic Data

*/
export default class Traffic {
  constructor(){
    
  }
}
