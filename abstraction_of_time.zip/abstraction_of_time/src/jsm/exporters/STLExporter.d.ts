import {Object3D} from "../../..";

export class STLExporter {
	constructor();

	parse(scene: Object3D, options: {});
}
